from torchvision import transforms

train_transform = transforms.Compose([
    transforms.Resize((64, 64)),
    transforms.RandomRotation(20),
    transforms.ColorJitter(brightness=0.4, contrast=0.4, saturation=0.4, hue=0.1),
    transforms.RandomAffine(degrees=0, translate=(0.1,0.1)),   # dịch chuyển
    transforms.RandomPerspective(distortion_scale=0.2, p=0.3), # biến dạng phối cảnh
    transforms.RandomHorizontalFlip(p=0.3),                    # lật ảnh
    transforms.GaussianBlur(kernel_size=3),                    # làm mờ
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406],
                         [0.229, 0.224, 0.225])
])

test_transform = transforms.Compose([
    transforms.Resize((64, 64)),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406],
                         [0.229, 0.224, 0.225])
])
