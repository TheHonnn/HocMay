import os
import pandas as pd
from torch.utils.data import Dataset, DataLoader
from PIL import Image

class GTSRBDataset(Dataset):
    def __init__(self, csv_file, root_dir, transform=None):
        """
        Args:
            csv_file (str): đường dẫn tới file CSV (Train.csv hoặc Test.csv)
            root_dir (str): thư mục gốc chứa ảnh (vd: data/raw_gtsrb)
            transform (callable, optional): các phép biến đổi ảnh
        """
        self.data = pd.read_csv(csv_file)
        self.root_dir = root_dir
        self.transform = transform

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        img_path = os.path.join(self.root_dir, self.data.iloc[idx]['Path'])
        image = Image.open(img_path)
        label = int(self.data.iloc[idx]['ClassId'])

        if self.transform:
            image = self.transform(image)

        return image, label

# Hàm tiện lợi để tạo DataLoader
def get_dataloader(csv_file, root_dir, transform, batch_size=64, shuffle=True, num_workers=0):
    dataset = GTSRBDataset(csv_file=csv_file, root_dir=root_dir, transform=transform)
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=shuffle, num_workers=num_workers)
    return loader
