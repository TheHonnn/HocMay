Data: https://www.kaggle.com/datasets/meowmeowmeowmeowmeow/gtsrb-german-traffic-sign
train code -> file.pth
start  
uvicorn app.main:app --reload
