import os
from fastapi import FastAPI, UploadFile, File, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from app.model_loader import get_model_and_classes
from PIL import Image
import io
import torch
import torch.nn.functional as F
import torchvision.transforms as transforms

app = FastAPI()

# Static + templates
app.mount("/static", StaticFiles(directory="app/static"), name="static")
templates = Jinja2Templates(directory="app/templates")

# Tạo folder uploads nếu chưa có
UPLOAD_FOLDER = "app/static/uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Load model
model, class_names, device = get_model_and_classes()

# Transform
transform = transforms.Compose([
    transforms.Resize((64, 64)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406],
                         std=[0.229, 0.224, 0.225])
])

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request, "result": None})

@app.post("/predict", response_class=HTMLResponse)
async def predict(request: Request, file: UploadFile = File(...)):
    # Lưu file upload vào static/uploads
    contents = await file.read()
    image = Image.open(io.BytesIO(contents)).convert("RGB")
    save_path = os.path.join(UPLOAD_FOLDER, file.filename)
    image.save(save_path)

    # Chuẩn hóa
    img_tensor = transform(image).unsqueeze(0).to(device)

    # Dự đoán
    with torch.no_grad():
        outputs = model(img_tensor)
        probs = F.softmax(outputs, dim=1)
        prob, pred_class = torch.max(probs, 1)

    result = {
        "class": class_names[pred_class.item()],
        "confidence": f"{prob.item():.2%}",
        "image_url": f"/static/uploads/{file.filename}"  # đường dẫn để hiển thị
    }

    return templates.TemplateResponse("index.html", {
        "request": request,
        "result": result
    })
