import torch
import torch.nn as nn
import pandas as pd
from torchvision.models import resnet50

SIGNNAMES_PATH = r"D:\3\Hoc May\BTL\traffic_sign_project (1)\data\raw_gtsrb\signnames.csv"
MODEL_PATH = r"D:\3\Hoc May\BTL\traffic_sign_project (1)\models\resnet50_best.pth"

def get_model_and_classes():
    # Load tên lớp
    signnames = pd.read_csv(SIGNNAMES_PATH)
    class_names = signnames["SignName"].tolist()

    # Load model
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = resnet50(weights=None)
    model.fc = nn.Sequential(
        nn.Dropout(0.5),
        nn.Linear(model.fc.in_features, len(class_names))
    )
    model.load_state_dict(torch.load(MODEL_PATH, map_location=device))
    model.to(device)
    model.eval()

    return model, class_names, device
