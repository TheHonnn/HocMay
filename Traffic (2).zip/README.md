SIGNNAMES_PATH = r"D:\3\Hoc May\BTL\traffic_sign_project (1)\data\raw_gtsrb\signnames.csv"
MODEL_PATH = r"D:\3\Hoc May\BTL\traffic_sign_project (1)\models\resnet50_best.pth"

start
uvicorn app.main:app --reload
